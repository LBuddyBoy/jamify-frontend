export default function QueuePage() {
    return <div>QueuePage</div>;
}